/*
 * This file is part of SuperLyric.
 *
 * SuperLyric is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *
 * Copyright (C) 2025-2026 HChenX
 */
package com.hchen.superlyric.provider.lx

import com.hchen.superlyric.kernel.model.LyricDoc
import com.hchen.superlyric.kernel.model.LyricLine
import com.hchen.superlyric.kernel.model.LyricWord
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertSame
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Test

class LxWordLyricTest {

    private val doc = LyricDoc(
        lines = listOf(
            LyricLine(12_340L, 15_000L, "晴天里"),
            LyricLine(15_000L, 18_000L, "Hello world"),
            LyricLine(18_000L, 20_000L, "不对应的行"),
        )
    )

    @Test
    fun parsesRelativeWordOffsets() {
        val lines = LxWordLyric.parse("[00:12.340]<0,350>晴<350,300>天<650,420>里")
        assertEquals(1, lines.size)
        assertEquals(
            listOf(LyricWord("晴", 12_340L, 12_690L), LyricWord("天", 12_690L, 12_990L), LyricWord("里", 12_990L, 13_410L)),
            lines.first().words,
        )
    }

    @Test
    fun attachesWordsToMatchingLinesOnly() {
        val words = """
            [00:12.34]<0,350>晴<350,300>天<650,420>里
            [00:15.000]<0,300>Hello<300,100> <400,500>world
            [00:18.000]<0,300>别的<300,300>歌词
        """.trimIndent()
        val result = LxWordLyric.attach(doc, words)
        assertEquals(3, result.lines[0].words.size)
        assertEquals(3, result.lines[1].words.size)
        assertEquals("Hello world", result.lines[1].words.joinToString("") { it.text })
        assertTrue(result.lines[2].words.isEmpty(), "text mismatch must stay line-level")
        // 行文本与行时间不变
        assertEquals(doc.lines.map { it.text to it.startMs }, result.lines.map { it.text to it.startMs })
    }

    @Test
    fun missingOrGarbageWordLyricKeepsTheDocument() {
        assertSame(doc, LxWordLyric.attach(doc, null))
        assertSame(doc, LxWordLyric.attach(doc, "not a lyric"))
        assertSame(doc, LxWordLyric.attach(doc, "[00:30.000]<0,100>远处"))
    }
}
