/*
 * This file is part of SuperLyric.
 *
 * SuperLyric is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *
 * Copyright (C) 2025-2026 HChenX
 */
package com.hchen.superlyric.provider.base

import com.hchen.superlyric.kernel.identity.TrackIdentity
import com.hchen.superlyric.kernel.model.LyricDoc
import com.hchen.superlyric.kernel.model.LyricLine
import com.hchen.superlyric.kernel.orchestrate.LyricSource
import com.hchen.superlyric.kernel.outcome.LyricOutcome
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Test
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * 无标识 Hook 点的时序归属：错投一首歌的歌词比不投更糟，这里钉住各个分支。
 */
private fun doc(text: String) = LyricDoc(lines = listOf(LyricLine(0L, 1_000L, text)))

class CapturedLyricSourceTest {

    private class Probe : CapturedLyricSource("Probe", replayWindowMs = 3_000L) {
        @Volatile
        var now = 10_000L

        override fun install() = Unit
        override fun nowMs(): Long = now
        fun push(key: String, text: String) = capture(key) { doc(text) }
        fun pushBlocking(key: String, text: String, gate: CountDownLatch) = capture(key) {
            gate.await(2, TimeUnit.SECONDS)
            doc(text)
        }
        fun boundary() = reset()
    }

    private class Recorder : LyricSource.Session {
        val outcomes = CopyOnWriteArrayList<LyricOutcome>()
        override fun deliver(outcome: LyricOutcome) {
            outcomes += outcome
        }
    }

    private fun track(title: String) = TrackIdentity("Test", null, title, "A", 200_000L)

    private fun awaitIdle() = Thread.sleep(150)

    private fun Recorder.successTexts() =
        outcomes.filterIsInstance<LyricOutcome.Success>().map { it.doc.lines.first().text }

    @Test
    fun firstTrackWaitsForTheHookInsteadOfYielding() {
        val source = Probe()
        val session = Recorder()
        source.start(track("one"), session)
        assertTrue(session.outcomes.isEmpty())
        source.push("k1", "one")
        awaitIdle()
        assertEquals(listOf("one"), session.successTexts())
    }

    @Test
    fun lyricBeforeMetadataIsReplayedToTheNewSession() {
        val source = Probe()
        source.push("k1", "first")
        awaitIdle()

        val session = Recorder()
        source.start(track("one"), session)
        assertEquals(listOf("first"), session.successTexts())
        assertEquals("one", (session.outcomes.first() as LyricOutcome.Success).doc.title)
    }

    @Test
    fun staleStashOutsideTheWindowIsNotReplayed() {
        val source = Probe()
        source.push("k1", "first")
        awaitIdle()
        source.now += 3_001L

        val session = Recorder()
        source.start(track("one"), session)
        assertTrue(session.successTexts().isEmpty())
    }

    @Test
    fun sessionReceivesCaptureOnce() {
        val source = Probe()
        val session = Recorder()
        source.start(track("one"), session)
        source.push("k1", "one")
        awaitIdle()
        assertEquals(listOf("one"), session.successTexts())

        // 同一载荷重发不会重复投递
        source.push("k1", "one")
        awaitIdle()
        assertEquals(1, session.outcomes.size)
    }

    @Test
    fun replayedPayloadIsNotStashedAgainForTheNextTrack() {
        val source = Probe()
        source.push("k1", "one")
        awaitIdle()

        val first = Recorder()
        source.start(track("one"), first)
        // 宿主在元数据之后重发同一份歌词
        source.push("k1", "one")
        awaitIdle()

        val second = Recorder()
        source.start(track("two"), second)
        assertEquals(listOf("one"), first.successTexts())
        assertTrue(second.successTexts().isEmpty())
    }

    @Test
    fun returningTrackGetsTheLyricAgainWithinTheSameTrackBoundary() {
        val source = Probe()
        val first = Recorder()
        source.start(track("one"), first)
        source.push("k1", "one")
        awaitIdle()

        source.start(track("glitch"), Recorder())
        val back = Recorder()
        source.start(track("one"), back)
        assertEquals(listOf("one"), back.successTexts())
    }

    @Test
    fun returningTrackIsNotReplayedAcrossATrackBoundary() {
        val source = Probe()
        source.start(track("one"), Recorder())
        source.push("k1", "one")
        awaitIdle()

        source.boundary()
        val back = Recorder()
        source.start(track("one"), back)
        assertTrue(back.successTexts().isEmpty())
    }

    /** 快速切歌：上一首还在解析时宿主切了歌，结果不能落到下一首上 */
    @Test
    fun parseInFlightAcrossATrackBoundaryIsDropped() {
        val source = Probe()
        val first = Recorder()
        source.start(track("one"), first)
        val gate = CountDownLatch(1)
        source.pushBlocking("k1", "one", gate)

        source.now += 1_000L
        source.boundary()
        val second = Recorder()
        source.start(track("two"), second)
        gate.countDown()
        awaitIdle()

        assertTrue(first.successTexts().isEmpty())
        assertTrue(second.successTexts().isEmpty(), "lyric of 'one' must not leak into 'two'")

        source.push("k2", "two")
        awaitIdle()
        assertEquals(listOf("two"), second.successTexts())
    }

    /** 切歌后、新元数据到达前就加载好的歌词，只能给新曲目，不能给旧会话 */
    @Test
    fun lyricAfterBoundaryGoesToTheNextSessionNotTheOldOne() {
        val source = Probe()
        val first = Recorder()
        source.start(track("one"), first) // 上一首没拿到歌词
        source.now += 1_000L
        source.boundary()
        source.push("k2", "two")
        awaitIdle()
        assertTrue(first.successTexts().isEmpty())

        val second = Recorder()
        source.start(track("two"), second)
        assertEquals(listOf("two"), second.successTexts())
    }

    /** 边界前极短时间内才开始的会话视为新曲目的会话（两条通道乱序） */
    @Test
    fun sessionStartedJustBeforeBoundaryStillReceivesTheLyric() {
        val source = Probe()
        val session = Recorder()
        source.start(track("two"), session)
        source.now += 50L
        source.boundary()
        source.push("k2", "two")
        awaitIdle()
        assertEquals(listOf("two"), session.successTexts())
    }

    /** 快速连切：暂存跨过曲目边界即作废，不会补投给下下一首 */
    @Test
    fun stashIsDiscardedAtTheNextBoundary() {
        val source = Probe()
        source.start(track("one"), Recorder())
        source.now += 1_000L
        source.boundary()
        source.push("k2", "two") // 暂存给 two
        awaitIdle()

        source.now += 500L
        source.boundary() // two 的元数据还没到就又切走了
        val third = Recorder()
        source.start(track("three"), third)
        assertTrue(third.successTexts().isEmpty())
    }

    @Test
    fun sameLyricAfterBoundaryIsAcceptedAgain() {
        val source = Probe()
        val first = Recorder()
        source.start(track("one"), first)
        source.push("k1", "one")
        awaitIdle()

        source.now += 1_000L
        source.boundary()
        val again = Recorder()
        source.start(track("one"), again)
        source.push("k1", "one") // 单曲重播：宿主重发同一份歌词
        awaitIdle()
        assertEquals(listOf("one"), again.successTexts())
    }

    @Test
    fun emptyParseAllowsTheSamePayloadToBeRetried() {
        val source = object : CapturedLyricSource("Empty") {
            var calls = 0
            override fun install() = Unit
            fun push() = capture("k") { calls++; if (calls == 1) LyricDoc.EMPTY else doc("ok") }
        }
        val session = Recorder()
        source.start(track("one"), session)
        source.push()
        awaitIdle()
        source.push()
        awaitIdle()
        assertEquals(listOf("ok"), session.successTexts())
    }
}
