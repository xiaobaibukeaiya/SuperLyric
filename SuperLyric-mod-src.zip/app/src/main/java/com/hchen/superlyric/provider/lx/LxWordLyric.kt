/*
 * This file is part of SuperLyric.
 *
 * SuperLyric is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *
 * Copyright (C) 2025-2026 HChenX
 */
package com.hchen.superlyric.provider.lx

import com.hchen.superlyric.kernel.model.LyricDoc
import com.hchen.superlyric.kernel.model.LyricWord

/**
 * LX 衍生版额外下发的逐字歌词（lxlyric）
 *
 * ## 格式
 * ```
 * [00:12.340]<0,350>晴<350,300>天<650,420>里
 * ```
 * 行首是行起始时间；`<偏移,时长>` 的偏移**相对行首**，单位毫秒。
 *
 * 原版 LX 1.9.1 不把这份数据交给桌面歌词模块；只有在 `setLyric` 第 4 个参数确实是字符串时才会用到。
 * 它只用来给已按 LRC 解析出的行补上逐字时序：行起始时间相近、且去掉空白后文本一致才补，
 * 对不上的行保持逐行，绝不改动行文本与行时间。
 */
internal object LxWordLyric {

    private val LINE_HEAD = Regex("""^\[(\d{1,3}):(\d{1,2})(?:[.:](\d{1,3}))?]""")
    private val WORD = Regex("""<(\d+),(\d+)>([^<]*)""")
    private val SPACE = Regex("""\s+""")

    /** 行起始时间允许的误差：LRC 常只有两位小数（10ms 精度） */
    private const val START_TOLERANCE_MS = 30L

    data class WordLine(val startMs: Long, val text: String, val words: List<LyricWord>)

    fun parse(text: String): List<WordLine> {
        val result = ArrayList<WordLine>()
        for (raw in text.lineSequence()) {
            val line = raw.trim()
            val head = LINE_HEAD.find(line) ?: continue
            val startMs = timestamp(head) ?: continue
            val words = ArrayList<LyricWord>()
            val builder = StringBuilder()
            for (match in WORD.findAll(line.substring(head.range.last + 1))) {
                val offset = match.groupValues[1].toLongOrNull() ?: continue
                val duration = match.groupValues[2].toLongOrNull() ?: continue
                val word = match.groupValues[3]
                if (word.isEmpty()) continue
                val wordStart = startMs + offset
                words += LyricWord(word, wordStart, wordStart + duration)
                builder.append(word)
            }
            if (words.isNotEmpty()) result += WordLine(startMs, builder.toString(), words)
        }
        return result
    }

    /** 给 [doc] 中能对上的行补逐字时序；一行都对不上时原样返回 */
    fun attach(doc: LyricDoc, wordLyric: String?): LyricDoc {
        if (wordLyric.isNullOrBlank()) return doc
        val wordLines = try {
            parse(wordLyric)
        } catch (_: Throwable) {
            return doc
        }
        if (wordLines.isEmpty()) return doc

        var changed = false
        val used = BooleanArray(wordLines.size)
        val lines = doc.lines.map { line ->
            if (line.hasWords) return@map line
            val key = compact(line.text)
            var best = -1
            var bestDelta = Long.MAX_VALUE
            for (index in wordLines.indices) {
                if (used[index]) continue
                val candidate = wordLines[index]
                val delta = kotlin.math.abs(candidate.startMs - line.startMs)
                if (delta <= START_TOLERANCE_MS && delta < bestDelta && compact(candidate.text) == key) {
                    best = index
                    bestDelta = delta
                }
            }
            if (best < 0) return@map line
            used[best] = true
            changed = true
            line.copy(words = wordLines[best].words)
        }
        return if (changed) doc.copy(lines = lines) else doc
    }

    private fun timestamp(match: MatchResult): Long? {
        val minutes = match.groupValues[1].toLongOrNull() ?: return null
        val seconds = match.groupValues[2].toLongOrNull() ?: return null
        val fraction = match.groupValues[3]
        val millis = when (fraction.length) {
            0 -> 0L
            1 -> fraction.toLong() * 100
            2 -> fraction.toLong() * 10
            else -> fraction.toLong()
        }
        return minutes * 60_000L + seconds * 1_000L + millis
    }

    private fun compact(text: String): String = SPACE.replace(text, "").lowercase()
}
