/*
 * This file is part of SuperLyric.
 *
 * SuperLyric is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *
 * Copyright (C) 2025-2026 HChenX
 */
package com.hchen.superlyric.provider.lx;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.hchen.hooktool.core.CoreTool;
import com.hchen.hooktool.hook.AbsHook;
import com.hchen.hooktool.log.AndroidLog;

import java.lang.reflect.Method;

/**
 * LX Music Hook 锚点：桌面歌词原生模块 {@code <pkg>.lyric.LyricModule#setLyric}
 *
 * <h3>为什么是这个点</h3>
 * {@code LyricModule} 是 LX Music 桌面歌词的 React Native 原生模块。JS 层
 * （{@code core/lyric.ts#handleSetLyric}）每次歌词加载完成都会把<b>整份 LRC</b>、译文、罗马音
 * 通过 {@code setLyric(lyric, translation, roma, promise)} 交给它；切歌 / 停止时
 * （{@code musicToggled} / {@code stop}）则以空串调用一次，清空桌面歌词。
 * 这个调用与桌面歌词开关无关：开关只决定原生侧是否创建悬浮窗（{@code LyricModule.lyric}），
 * 方法本身每首歌都会被调用。它是 {@code @ReactMethod}，按名字反射调用，不会被混淆。
 *
 * <p>部分衍生版在第 4 个参数额外传入逐字歌词（{@code [mm:ss.xxx]<偏移,时长>字}），有则一并转交；
 * 原版 LX 1.9.1 第 4 个参数是 {@code Promise}，忽略即可。
 *
 * <p>Hook 方案参照 LyricProvider 的 {@code lx-music} 插件（Apache-2.0，Proify / Tomakino）重新实现。
 * 插件另外挂了 {@code play / pause / setPlaybackRate / toggleTranslation / toggleRoma} 与
 * {@code MediaSession} 来自行推算进度；本模块的进度由框架侧从 {@code MediaSession} 推导（CLAUDE.md L3），
 * 因此只保留取词这一个点。
 */
public final class LxAnchors {
    private static final String TAG = "LxAnchors";

    /** 仅在至少挂上一个 setLyric 之后置位；定位失败时允许下一次 install 重试 */
    private static volatile boolean sInstalled;

    /**
     * 当前接收者。Hook 只挂一次，但宿主就绪回调可能再次分发、重建 Provider 与 Hook 来源，
     * 因此回调总是转交给<b>最近一次</b> install 传入的 listener，而不是挂钩时捕获的那个
     */
    @Nullable
    private static volatile LyricListener sListener;

    private LxAnchors() {
    }

    public interface LyricListener {
        /** 宿主交出一份新歌词；{@code wordLyric} 仅部分衍生版提供 */
        void onLyric(@NonNull String lyric, @Nullable String translation, @Nullable String roma,
                     @Nullable String wordLyric);

        /** 宿主以空歌词调用：切歌或停止，之前的歌词不再属于当前曲目 */
        void onCleared();
    }

    public static synchronized void install(@NonNull String lyricModuleClass, @NonNull LyricListener listener) {
        sListener = listener;
        if (sInstalled) return;

        try {
            Class<?> moduleClass = CoreTool.findClassIfExists(lyricModuleClass);
            if (moduleClass == null) {
                AndroidLog.logW(TAG, lyricModuleClass + " not found");
                return;
            }

            int hooked = 0;
            for (Method method : moduleClass.getDeclaredMethods()) {
                if (!"setLyric".equals(method.getName())) continue;
                Class<?>[] params = method.getParameterTypes();
                if (params.length < 1 || params[0] != String.class) continue;

                try {
                    method.setAccessible(true);
                    CoreTool.hook(method, new AbsHook() {
                        @Override
                        public void after() {
                            try {
                                dispatch(getArgs());
                            } catch (Throwable t) {
                                AndroidLog.logW(TAG, "Error in setLyric hook: " + t.getMessage());
                            }
                        }
                    });
                    hooked++;
                    // 挂上一个就置位：后续方法挂钩失败时重试也不会把已挂的重复挂一遍
                    sInstalled = true;
                } catch (Throwable t) {
                    AndroidLog.logW(TAG, "Failed to hook " + method + ": " + t.getMessage());
                }
            }

            if (hooked == 0) {
                AndroidLog.logW(TAG, "No setLyric(String, ...) on " + lyricModuleClass);
            } else {
                AndroidLog.logI(TAG, "Hooked " + hooked + " setLyric entry on " + lyricModuleClass);
            }
        } catch (Throwable t) {
            AndroidLog.logE(TAG, "Failed to install LX anchors", t);
        }
    }

    private static void dispatch(@Nullable Object[] args) {
        LyricListener current = sListener;
        if (current == null || args == null) return;
        String lyric = stringArg(args, 0);
        if (lyric == null || lyric.isBlank()) {
            current.onCleared();
            return;
        }
        current.onLyric(lyric, stringArg(args, 1), stringArg(args, 2), stringArg(args, 3));
    }

    @Nullable
    private static String stringArg(@NonNull Object[] args, int index) {
        if (index >= args.length) return null;
        return args[index] instanceof String s && !s.isBlank() ? s : null;
    }
}
