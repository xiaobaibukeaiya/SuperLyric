/*
 * This file is part of SuperLyric.
 *
 * SuperLyric is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *
 * Copyright (C) 2025-2026 HChenX
 */
package com.hchen.superlyric.provider.lx;

import androidx.annotation.NonNull;

import com.hchen.processor.HookThis;

/**
 * LX Music 衍生版（{@code com.lxnetease.music.mobile}），取词逻辑与 {@link LxMusicProvider} 完全一致。
 */
@HookThis(targetPackage = "com.lxnetease.music.mobile")
public class LxNeteaseProvider extends LxMusicProvider {
    @Override
    protected String getProviderTag() {
        return "LxNeteaseProvider";
    }

    @NonNull
    @Override
    protected String lyricModuleClass() {
        return "com.lxnetease.music.mobile.lyric.LyricModule";
    }
}
