/*
 * This file is part of SuperLyric.
 *
 * SuperLyric is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *
 * Copyright (C) 2025-2026 HChenX
 */
package com.hchen.superlyric.provider.lx;

import androidx.annotation.NonNull;

import com.hchen.processor.HookThis;
import com.hchen.superlyric.kernel.orchestrate.LyricOrchestrator;
import com.hchen.superlyric.kernel.orchestrate.LyricSource;
import com.hchen.superlyric.provider.base.HookLyricSource;
import com.hchen.superlyric.provider.base.MusicProvider;
import com.hchen.superlyric.provider.kugou.KuGouApiSource;

/**
 * LX Music（洛雪音乐）歌词提供者。
 *
 * <h3>取词路径</h3>
 * <ul>
 *   <li><b>Hook 路径</b>：桌面歌词模块 {@code LyricModule.setLyric} 交出的整份 LRC + 译文 + 罗马音
 *       （衍生版另有逐字），Hook 方案参照 LyricProvider 的 {@code lx-music} 插件。
 *       JS 层每首歌都会调用，无需开启桌面歌词、也无需悬浮窗权限。</li>
 *   <li><b>API 路径（兜底）</b>：复用酷狗开放接口按曲名 + 歌手检索。</li>
 * </ul>
 *
 * <p>曲目身份沿用基类的 {@code MediaSession} 元数据（LX 不带 {@code MEDIA_ID}，按标题 + 歌手 + 时长判定）。
 * LX 的「蓝牙歌词」会把标题逐行改写成歌词，本模块不做还原，使用时需保持其关闭。
 *
 * <p>同一套代码也服务于 LX 的几个衍生版（ikunshare / lxnetease / lxwalnut），
 * 它们只是包名与 {@code LyricModule} 所在包不同，见同目录下的子类。
 */
@HookThis(targetPackage = "cn.toside.music.mobile")
public class LxMusicProvider extends MusicProvider {
    private static final String TAG = "LxMusicProvider";

    @Override
    protected String getProviderTag() {
        return TAG;
    }

    /** {@code LyricModule} 的完整类名；衍生版覆写。 */
    @NonNull
    protected String lyricModuleClass() {
        return "cn.toside.music.mobile.lyric.LyricModule";
    }

    @NonNull
    @Override
    protected HookLyricSource createHookSource() {
        return new LxHookSource(lyricModuleClass());
    }

    @NonNull
    @Override
    protected LyricSource createApiSource() {
        return new KuGouApiSource();
    }

    /**
     * LX 的歌词由 JS 层在切歌后异步加载（可能还要走一次网络），
     * 默认 800ms 的 Hook 窗口太短，会过早落到检索兜底。
     */
    @NonNull
    @Override
    protected LyricOrchestrator.Config orchestratorConfig() {
        return new LyricOrchestrator.Config(3_000L, 3, 500L, 3_000L);
    }
}
