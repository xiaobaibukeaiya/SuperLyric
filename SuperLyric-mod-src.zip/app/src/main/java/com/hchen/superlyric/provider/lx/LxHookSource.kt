/*
 * This file is part of SuperLyric.
 *
 * SuperLyric is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *
 * Copyright (C) 2025-2026 HChenX
 */
package com.hchen.superlyric.provider.lx

import com.hchen.superlyric.kernel.pipeline.LyricFormat
import com.hchen.superlyric.kernel.pipeline.LyricRequest
import com.hchen.superlyric.provider.base.CapturedLyricSource
import com.hchen.superlyric.utils.LyricDiag

/**
 * LX Music Hook 取词来源：解析宿主交给桌面歌词模块 `LyricModule.setLyric` 的 LRC / 译文 / 罗马音，
 * 衍生版若额外给出逐字歌词则补上逐字时序（见 [LxWordLyric]）
 *
 * 宿主不在这个点附带曲目标识，归属由 [CapturedLyricSource] 按时序判断；
 * 宿主切歌 / 停止时以空歌词调用同一方法，正好作为曲目边界（[reset]），
 * 上一首迟到的解析结果因此不会落到下一首上。
 *
 * LX 的 JS 层每首歌都会调用 `setLyric`，与桌面歌词开关无关
 * （`core/lyric.ts#handleSetLyric` 无条件调用 `setDesktopLyric`），无需开启桌面歌词。
 */
class LxHookSource(
    private val lyricModuleClass: String,
) : CapturedLyricSource("LxHook", replayWindowMs = REPLAY_WINDOW_MS) {

    override fun install() {
        LxAnchors.install(lyricModuleClass, object : LxAnchors.LyricListener {
            override fun onLyric(lyric: String, translation: String?, roma: String?, wordLyric: String?) {
                val key = "${lyric.hashCode()}:${translation?.hashCode() ?: 0}:" +
                    "${roma?.hashCode() ?: 0}:${wordLyric?.hashCode() ?: 0}"
                capture(key) {
                    LyricDiag.parse(
                        sourceName,
                        LyricRequest(
                            format = LyricFormat.GENERAL,
                            text = lyric,
                            translationText = translation,
                            phoneticText = roma,
                        )
                    )?.let { LxWordLyric.attach(it, wordLyric) }
                }
            }

            override fun onCleared() = reset()
        })
    }

    private companion object {
        /**
         * 歌词常比元数据先到（LX 要先取播放地址才更新 `MediaSession`）。暂存有曲目边界保护，
         * 跨过一次切歌（宿主的空歌词调用）即作废，因此窗口可以比默认的 3 秒宽得多，
         * 避免取播放地址慢时白白落到检索兜底
         */
        const val REPLAY_WINDOW_MS = 60_000L
    }
}
