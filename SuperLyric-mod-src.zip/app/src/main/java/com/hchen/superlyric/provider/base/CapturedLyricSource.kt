/*
 * This file is part of SuperLyric.
 *
 * SuperLyric is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Copyright (C) 2025-2026 HChenX
 */
package com.hchen.superlyric.provider.base

import com.hchen.hooktool.log.AndroidLog
import com.hchen.superlyric.kernel.identity.TrackIdentity
import com.hchen.superlyric.kernel.model.LyricDoc
import com.hchen.superlyric.kernel.orchestrate.LyricSource
import com.hchen.superlyric.kernel.outcome.LyricOutcome

import java.util.concurrent.Executors

/**
 * Hook 取词来源的公共骨架：宿主把**整份歌词**交给某个点位，但不附带任何曲目标识
 *
 * 适用于 LX Music（桌面歌词模块 `LyricModule.setLyric`）这类宿主：Hook 点只能拿到歌词本身，
 * 归属哪首曲目只能靠**时序**判断。
 *
 * ## 时序规则
 * - 歌词到达时若当前会话尚未收到 Hook 结果，直接投递给它。
 * - 否则暂存；新会话在 [start] 时若暂存足够新（[replayWindowMs] 内）则补投。
 *   这覆盖了"宿主先加载歌词、后更新 `MediaSession` 元数据"的顺序。
 * - 暂存一旦投递即清空，避免把上一首的歌词补投给下一首。
 *
 * ## 曲目边界（[reset]）
 * 宿主若能告知"切歌 / 停止了"（LX 以空歌词调用同一方法），子类调用 [reset]：
 * - 边界之前开始、尚未完成的解析结果作废，不会落到下一首上（快速切歌串歌词）；
 * - 边界之前的暂存与"同曲补投"记录作废；
 * - 边界之前就已存在的会话属于上一首，之后到达的歌词改为暂存、留给下一首的会话。
 *   为容忍宿主两条通道的微小乱序，边界前 [RESET_GRACE_MS] 内才开始的会话仍视为新曲目的会话。
 *
 * 解析在独立线程上进行，[start] 只做赋值，满足编排器"start 必须快速返回"的约束。
 */
abstract class CapturedLyricSource(
    final override val sourceName: String,
    private val replayWindowMs: Long = DEFAULT_REPLAY_WINDOW_MS,
) : HookLyricSource {

    private val executor = Executors.newSingleThreadExecutor { runnable ->
        Thread(runnable, "SuperLyric-$sourceName").apply { isDaemon = true }
    }

    private val lock = Any()

    private var session: LyricSource.Session? = null
    private var identity: TrackIdentity? = null
    private var deliveredInSession = false
    private var sessionStartedAtMs = 0L

    /** 曲目边界代数：每次 [reset] 自增 */
    private var generation = 0L

    private var stashedDoc: LyricDoc? = null
    private var stashedKey: String? = null
    private var stashedAtMs: Long = 0L
    private var stashedGeneration: Long = -1L

    private var lastPayloadKey: String? = null

    /**
     * 最近一次投递出去的歌词、所属曲目与代数
     *
     * 编排器对同一首歌重建会话时（元数据短暂抖动），宿主不会再调用 Hook 点，只能由这里补投；
     * 跨过曲目边界即作废。
     */
    private var lastDelivered: Triple<TrackIdentity, LyricDoc, Long>? = null

    override fun start(identity: TrackIdentity, session: LyricSource.Session) {
        val replay: LyricDoc?
        var again: LyricDoc? = null
        synchronized(lock) {
            this.session = session
            this.identity = identity
            deliveredInSession = false
            sessionStartedAtMs = nowMs()
            lastPayloadKey = null

            val stashed = stashedDoc
            replay = if (
                stashed != null && stashedGeneration == generation &&
                nowMs() - stashedAtMs <= replayWindowMs
            ) stashed else null
            if (replay != null) {
                deliveredInSession = true
                // 宿主常在元数据之后再重发同一份歌词，补投过的载荷不能再被暂存给下一首
                lastPayloadKey = stashedKey
                lastDelivered = Triple(identity, replay, generation)
            }
            stashedDoc = null
            stashedKey = null

            if (replay == null) {
                val previous = lastDelivered
                if (previous != null && previous.third == generation && previous.first.matches(identity)) {
                    again = previous.second
                    deliveredInSession = true
                }
            }
        }
        again?.let {
            AndroidLog.logD(sourceName, "Re-delivering lyric to returning track ${identity.title}")
            session.deliver(LyricOutcome.Success(it.withIdentity(identity)))
            return
        }
        if (replay != null) {
            AndroidLog.logD(sourceName, "Replaying lyric captured before metadata for ${identity.title}")
            session.deliver(LyricOutcome.Success(replay.withIdentity(identity)))
        }
    }

    override fun cancel() {
        synchronized(lock) {
            session = null
            identity = null
            deliveredInSession = false
        }
    }

    /** 宿主告知曲目边界（切歌 / 停止）；见类注释 */
    protected fun reset() {
        synchronized(lock) {
            generation++
            stashedDoc = null
            stashedKey = null
            lastPayloadKey = null
            lastDelivered = null
            // 边界之前就存在的会话属于上一首：不再接收边界之后的歌词
            if (session != null && nowMs() - sessionStartedAtMs > RESET_GRACE_MS) {
                deliveredInSession = true
            }
        }
    }

    /**
     * 宿主交出了一份歌词
     *
     * @param payloadKey 用于去重的载荷摘要；同一会话内重复调用不会重复解析
     * @param parser     在后台线程执行的解析；返回 null 或空文档视为本次未取到
     */
    protected fun capture(payloadKey: String, parser: () -> LyricDoc?) {
        val capturedGeneration: Long
        synchronized(lock) {
            if (payloadKey == lastPayloadKey) return
            lastPayloadKey = payloadKey
            capturedGeneration = generation
        }
        executor.execute {
            val doc = try {
                parser()
            } catch (t: Throwable) {
                AndroidLog.logW(sourceName, "Failed to parse captured lyric: ${t.message}")
                null
            }
            if (doc == null || doc.isEmpty) {
                AndroidLog.logW(sourceName, "Captured lyric parsed to no lines")
                synchronized(lock) {
                    // 允许宿主重发同一载荷时再试一次
                    if (lastPayloadKey == payloadKey) lastPayloadKey = null
                }
                return@execute
            }

            val target: LyricSource.Session?
            val current: TrackIdentity?
            val stale: Boolean
            synchronized(lock) {
                stale = capturedGeneration != generation
                if (stale) {
                    target = null
                    current = null
                } else if (session != null && !deliveredInSession) {
                    target = session
                    current = identity
                    deliveredInSession = true
                    identity?.let { lastDelivered = Triple(it, doc, generation) }
                } else {
                    target = null
                    current = null
                    stashedDoc = doc
                    stashedKey = payloadKey
                    stashedAtMs = nowMs()
                    stashedGeneration = generation
                }
            }

            if (stale) {
                AndroidLog.logD(sourceName, "Track changed while parsing; dropping stale lyric")
            } else if (target != null) {
                AndroidLog.logI(sourceName, "Captured lyric, lines=${doc.lines.size}")
                target.deliver(LyricOutcome.Success(doc.withIdentity(current)))
            } else {
                AndroidLog.logD(sourceName, "Stashed lyric (lines=${doc.lines.size}) until the next track session")
            }
        }
    }

    /** 曲目信息一律以会话身份为准：解析时可能还拿着上一首的元数据 */
    private fun LyricDoc.withIdentity(identity: TrackIdentity?): LyricDoc {
        if (identity == null) return this
        return copy(
            title = identity.title.ifBlank { title },
            artist = identity.artist.ifBlank { artist },
            durationMs = if (identity.durationMs > 0L) identity.durationMs else durationMs,
            lyricId = identity.stableId ?: lyricId,
        )
    }

    /** 可覆写以便测试 */
    protected open fun nowMs(): Long = System.nanoTime() / 1_000_000L

    private companion object {
        const val DEFAULT_REPLAY_WINDOW_MS = 3_000L
        const val RESET_GRACE_MS = 150L
    }
}
