# SuperLyric NEXT 说明

基于 HChenX/SuperLyric 上游 master `8f7a233`（GPL-3.0）。除下列内容外，代码与作用域均与上游一致。

## 相对上游的改动

1. **洛雪音乐（LX Music）支持**：Hook 方案参照 LyricProvider（tomakino/LyricProvider，Apache-2.0）的 `lx-music` 插件
   （「洛雪音乐歌词支持」3.0.0），在 SuperLyric 自己的 Provider / 内核 API 上重新实现。
   - 取词点：桌面歌词原生模块 `<pkg>.lyric.LyricModule#setLyric(lyric, translation, roma, …)`。
     LX 的 JS 层每首歌都会调用它，与桌面歌词开关无关，**无需开启桌面歌词，也无需悬浮窗权限**。
     衍生版若在第 4 个参数给出逐字歌词（`[mm:ss.xxx]<偏移,时长>字`），则补到对应行上（`LxWordLyric`）。
   - 曲目边界：LX 切歌 / 停止时以空歌词调用 `setLyric`，`CapturedLyricSource#reset` 据此作废上一首
     未完成的解析、暂存与旧会话，修复「快速切歌串歌词」。
   - 进度不取自宿主：插件挂的 `play / pause / setPlaybackRate / toggleTranslation / toggleRoma` 与
     `MediaSession` 均不挂，进度由框架侧从 `MediaSession` 推导（CLAUDE.md L3）。
   - 已移除「蓝牙歌词」还原方案（`LxTitleResolver` 及其单测）。LX 的「蓝牙歌词」会逐行改写标题，需保持关闭。
   - `provider/lx/`：`LxAnchors`、`LxHookSource`、`LxWordLyric`、`LxMusicProvider`（`cn.toside.music.mobile`）
     及衍生版 `IKunShareProvider` / `LxNeteaseProvider` / `LxWalnutProvider`（类名与原版一致，仅包名不同）。
   - `provider/base/CapturedLyricSource.kt`：Hook 只给歌词、不给曲目标识时的时序归属骨架（含曲目边界代数）。
   - API 兜底复用上游 `KuGouApiSource`（按曲名 + 歌手检索）。
   - 注册：`@HookThis`、`META-INF/xposed/scope.list`（上游作用域 + 4 个 LX 包名）、`SupportApps` + `luoxue_music` 文案。
   - 单测：`CapturedLyricSourceTest`、`LxWordLyricTest`。
2. **关于页**：在原作者「焕晨」下方新增修改者条目「酷安@超级无敌柴郡酱」（头像 `res/drawable/cheshire.webp`）。
3. **Xposed API 102**：`META-INF/xposed/module.prop` 的 `minApiVersion` / `targetApiVersion` = 102
   （依赖本就是 `io.github.libxposed:api:102.0.0`；热重载仍由 `HookEntrance#isHotReloadingAllowed` 关闭）。
   需要 LSPosed v2.1.0（7769）或更新版本。
4. 应用名「SuperLyric NEXT」（包名仍为 `com.hchen.superlyric`），版本 `NEXT1.0`（versionCode 2026102110）。
5. 各应用「使用方法」提示改写为更直白的说法（`values{,-zh-rCN}/strings.xml`）；关于页头像缩到 192px。

## 构建

JDK 21 + Android SDK (platform 37)：

    ./gradlew :app:assembleRelease
    ./gradlew :lyric-kernel:test :app:testDebugUnitTest

## 许可

SuperLyric 为 GPL-3.0；LX 部分移植自 LyricProvider（Copyright 2026 Proify, Tomakino，Apache-2.0），见 `NOTICE-LyricProvider`。
